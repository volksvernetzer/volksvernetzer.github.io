# gulp-basic-frontend
Basic Gulp frontend workflow. SASS with Autoprefixer and gulp-purifycss to cleanup unused CSS, JS concatenation, Spritesheets, Image minification, Twig templating with easier schema integration via posthtml-schemas and BrowserSync.

# Getting Started
Get Node.js and NPM, then run `npm install` in folder's directory to install dependencies.

# Tasks
- `sass` - compiles SASS files, adds browser prefixes with Autoprefixer
- `scripts` - concatenates JS files, uglifies them
- `purifycss` - cleans up unused code from CSS files
- `twig` - compiles Twig templates in 'src/templates/pages'
- `twig-partials` - compiles Twig templatey in 'src/templates/interchange-partials'
- `imagemin` - minifies images
- `spritesmith` - creates spritesheet
- `a11y` - runs a11y diagnostics

`default` runs all `sass`, `scripts`, `twig`, `spritesmith`, watchers and BrowserSync (the synchronization is bugged on .twig templates, so at most 2 reloads are needed).

Just prepend tasks with `gulp` and you are good to go. (example: `gulp` runs default)

Foundation include directory is prepared to be used, as is in main.scss (src/styles/main.scss)