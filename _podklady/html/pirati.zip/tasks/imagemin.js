'use strict';

var gulp          = require('gulp'),
    gulpImagemin  = require('gulp-imagemin'),
    browserSync   = require('browser-sync');

module.exports = () => {
  gulp.task('imagemin', () => {
    gulp.src('./src/images/**/*')
      .pipe(gulpImagemin())
      .pipe(gulp.dest('dist/images'))
      .pipe(browserSync.stream());
  });

  gulp.task('imagemin:watch', () => {
    gulp.watch('./src/images/**/*', ['imagemin']);
  });
};