'use strict';

var fs            = require('fs'),
    glob          = require('glob'),
    path          = require('path'),
    gulp          = require('gulp'),
    gulpTwig      = require('gulp-twig'),
    gulpPlumber   = require('gulp-plumber'),
    gulpPrettify  = require('gulp-prettify'),
    gulpData      = require('gulp-data'),
    gulpForeach   = require('gulp-foreach'),
    gulpPosthtml  = require('gulp-posthtml'),
    browserSync   = require('browser-sync');

module.exports = () => {
  gulp.task('twig-partials', () => {
    return gulp.src('./src/templates/interchange-partials/**/*.twig')
      .pipe(gulpPlumber({
        errorHandler: (err) => {
          console.log(err.message);
        }
      }))
      .pipe(gulpData( (file, callback) => {
        glob("./src/templates/config/*.json", {}, (err, files) => {
          var data = {};
          if (files.length) {
            files.forEach( (fPath) => {
              var baseName = path.basename(fPath, '.json');
              data[baseName] = JSON.parse(fs.readFileSync(fPath));
            });
          }
          callback(undefined, data);
        });
      }))
      .pipe(gulpForeach( (stream, file) => {
        return stream
          .pipe(gulpTwig())
      }))
      .pipe(gulpPrettify())
      .pipe(gulpPosthtml([
        require('posthtml-schemas')(),
      ]))
      .pipe(gulp.dest('./dist/partials'))
      .pipe(browserSync.stream());
  });

  gulp.task('twig-partials:watch', () => {
    gulp.watch(['./src/templates/**/*.twig', './src/templates/config/*.json'], {debounceDelay: 200}, ['twig-partials']);
  });
};