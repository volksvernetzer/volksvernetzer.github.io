'use strict';

var gulp          = require('gulp'),
    browserSync   = require('browser-sync');

module.exports = () => {
  gulp.task('browser-sync', () => {
    browserSync.init({
        server: {
            baseDir: "./dist"
        }
    });
  });
};