'use strict';

var gulp          = require('gulp'),
    gulpA11y      = require('gulp-a11y'),
    gulpRename    = require('gulp-rename'),
    gulpBeautify  = require('gulp-beautify');

module.exports = () => {
  gulp.task('a11y', () => {
    return gulp.src('./dist/*.html')
      .pipe(gulpA11y())
      .pipe(gulpA11y.reporter())
  });
};